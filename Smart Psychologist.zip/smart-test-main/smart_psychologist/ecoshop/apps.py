from django.apps import AppConfig


class EcoshopConfig(AppConfig):
    name = 'ecoshop'
