from django.apps import AppConfig


class UseraccountConfig(AppConfig):
    name = 'useraccount'
